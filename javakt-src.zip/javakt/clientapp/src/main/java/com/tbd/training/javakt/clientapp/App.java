package com.tbd.training.javakt.clientapp;

import com.tbd.training.javakt.common.QuickStart;

public class App {
	public static void main(String[] args) {
		QuickStart qs = new QuickStart();
		System.out.println(qs.dummy());
	}
}
