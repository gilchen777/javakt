package com.tbd.training.javakt.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import com.tbd.training.javakt.common.logging.AppLogger;

public class WordCounter {
    private static AppLogger logger = AppLogger.getLogger(WordCounter.class);
	
	public List<String> findTopXWords(String fileName, String encoding, int topX) {
		if (StringUtil.nullOrEmpty(encoding)) {
			encoding = "UTF-8";
		}
		if (topX <=0) {
			topX = 10;
		}
		
		Map<String, Integer> result = count(fileName, encoding);
		
		Map<String, Integer> sortedResult = sortWords(result);
		
		logger.info("start to print top repeated words...");
		List<String> reval = new ArrayList<String>();
		for(String word : sortedResult.keySet()) {
			logger.info(word + " " + sortedResult.get(word));
			topX = topX - 1;
			reval.add(word);
			if (topX == 0) {
				break;
			}
		}
		
		return reval;
	}
	
	public Map<String, Integer> count(String fileName, String encoding) {
		Map<String, Integer> reval = new TreeMap<String, Integer>();
		File file = new File(fileName);
		if (StringUtil.nullOrEmpty(encoding)) {
			encoding = "UTF-8";
		}

		try (FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis, encoding);
				BufferedReader reader = new BufferedReader(isr, 1024))
		{

			String str;
			while ((str = reader.readLine()) != null) {
				countWordFromString(reval, str);
			}
			
			logger.debug("print all result sorted");
			for(String word : reval.keySet()) {
				logger.debug(word + " " + reval.get(word));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reval;
	}
	
	private Map<String, Integer> countWordFromString(Map<String, Integer> preResult, String lineOfWords) {
		if (StringUtil.nullOrEmpty(lineOfWords)) {
			return null;
		}
		
		Set<String> toBeIngoredOnes = getIgnoreWords();
		if (preResult == null) {
			preResult = new HashMap<String, Integer>();
		}
	
		String[] goodWords = lineOfWords.split("([,.;\\s]+)");
		for (String word : goodWords) {
			if(!StringUtil.nullOrEmpty(word)) {
				String lowerCaseWord = word.toLowerCase();
				if (!toBeIngoredOnes.contains(lowerCaseWord)) {
					if (!preResult.containsKey(lowerCaseWord)) {
						preResult.put(lowerCaseWord, 1);
					} else {
						logger.debug("count this word: " + lowerCaseWord);
						preResult.put(lowerCaseWord, preResult.get(lowerCaseWord) + 1);
					}
				}
			}
			
		}
		return preResult;
	}
	
	private Map<String, Integer> sortWords(Map<String, Integer> wordCounts) {
		return wordCounts.entrySet().stream()
				.sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()))	
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
	}
	
	private Set<String> getIgnoreWords() {
		Set<String> reval = new HashSet<String>();
		reval.add("is");
		reval.add("isn't");
		reval.add("was");
		reval.add("wansn't");
		reval.add("are");
		reval.add("aren't");
		reval.add("the");
		reval.add("a");
		reval.add("an");
		reval.add("not");
		reval.add("they");
		reval.add("it");
		reval.add("do");
		reval.add("don't");
		reval.add("does");
		reval.add("doesn't");
		reval.add("will");
		reval.add("won't");
		reval.add("can");
		reval.add("can't");
		reval.add("am");
		reval.add("could");
		reval.add("of");
		reval.add("and");
		reval.add("or");
		reval.add("to");
		reval.add("our");
		reval.add("on");
		reval.add("with");
		reval.add("at");
		reval.add("in");
		reval.add("for");
		reval.add("as");
		reval.add("this");
		reval.add("that");
		reval.add("which");
		reval.add("what");
		reval.add("as");
		reval.add("such");
		reval.add("so");
		reval.add("by");
		reval.add("on");
		return reval;
	}
}
