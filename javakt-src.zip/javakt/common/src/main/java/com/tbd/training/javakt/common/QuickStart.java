package com.tbd.training.javakt.common;

import com.tbd.training.javakt.common.logging.AppLogger;

public class QuickStart {
	private static AppLogger logger = AppLogger.getLogger(QuickStart.class);
	public String dummy() {
		long start = System.currentTimeMillis();
		doWork();
		
		long end = System.currentTimeMillis();
		logger.info("dummy() takes "  +  (end-start)/1000 + "s");
		return "dummy";
	}
	
	private void doWork() {
		logger.info("do something...");
		try {
			
			Thread.sleep(3000);
		} catch(InterruptedException e) {
			logger.error("Error on do work", e);
		}
		
	}
}
