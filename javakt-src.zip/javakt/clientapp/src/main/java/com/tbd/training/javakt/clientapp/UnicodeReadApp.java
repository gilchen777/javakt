package com.tbd.training.javakt.clientapp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class UnicodeReadApp {
	public static void main(String[] args) {
		String fileName = "/f:/temp/test-utf8.txt"; //  f:\\temp\\test-utf8.txt
		String file2 = "/f:/temp/test-gb2312.txt";

		readUnicodeClassic(fileName, "UTF-8");
		
		System.out.println("#############################");
		readUnicodeClassic(file2, "GB2312");
		
		System.out.println(System.getProperties().getProperty("user.home"));
	}

	public static void readUnicodeClassic(String fileName, String encoding) {
		File file = new File(fileName);
		try (FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis, encoding);
				BufferedReader reader = new BufferedReader(isr))
		{
			String str;
			while ((str = reader.readLine()) != null) {
				System.out.println(str);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
