package com.tbd.training.javakt.common;

public class BaseTest {

}
