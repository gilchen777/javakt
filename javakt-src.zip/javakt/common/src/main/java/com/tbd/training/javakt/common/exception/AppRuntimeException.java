package com.tbd.training.javakt.common.exception;

import com.tbd.training.javakt.common.logging.AppLogger;
import com.tbd.training.javakt.common.logging.LogOnce;

public class AppRuntimeException extends RuntimeException implements LogOnce {
	private static final long serialVersionUID = 1L;
	private Boolean alreadyLogged = Boolean.FALSE;

    public AppRuntimeException() {
        super();
    }

    public AppRuntimeException(String message, Throwable cause, boolean logging) {
        super(message, cause);
        if (logging && !alreadyLogged) {
            AppLogger logger = AppLogger.getLogger(AppRuntimeException.class);
            logger.error(message, cause);
            alreadyLogged = Boolean.TRUE;
        }
    }

    public AppRuntimeException(String message, Throwable cause) {
        this(message, cause, true);
    }

    public AppRuntimeException(String message) {
        super(message);
    }

    public AppRuntimeException(Throwable cause) {
         this(cause.toString(), cause, true);
    }

    public Boolean isAlreadyLogged() {
        return alreadyLogged;
    }

    public void setAlreadyLogged(Boolean alreadyLogged) {
        this.alreadyLogged = alreadyLogged;
    }

}
