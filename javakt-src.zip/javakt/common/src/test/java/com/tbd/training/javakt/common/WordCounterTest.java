package com.tbd.training.javakt.common;

import org.junit.Test;


public class WordCounterTest {
	
	@Test
	public void testTop10Words() {
		String file = "f:\\temp\\WordCounter.txt";
		WordCounter target = new WordCounter();
		System.out.println(target.findTopXWords(file, null, 10));
	}
	
	@Test
	public void testTop10Words2() {
		String file = "f:\\temp\\WordCounter2.txt";
		WordCounter target = new WordCounter();
		System.out.println(target.findTopXWords(file, null, 10));
	}
	
	@Test
	public void testTop10Words3() {
		String file = "f:\\temp\\WordCounter3.txt";
		WordCounter target = new WordCounter();
		System.out.println(target.findTopXWords(file, null, 10));
	}
}
