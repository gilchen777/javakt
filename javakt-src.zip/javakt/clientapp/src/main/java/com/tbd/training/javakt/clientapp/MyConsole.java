package com.tbd.training.javakt.clientapp;

import java.util.Scanner;

public class MyConsole {
	public static void main(String[] args) {
		System.out.println("please input something, type 'exit' to end...");
		Scanner src = new Scanner(System.in);
		String text = src.nextLine();
		while (!text.equalsIgnoreCase("exit")) {
			System.out.println("hello [" + text + "]! :)");			
			text = src.nextLine();
		}
		src.close();
		System.out.println("exiting...");
	}
}
