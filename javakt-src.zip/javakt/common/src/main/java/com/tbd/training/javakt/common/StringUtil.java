package com.tbd.training.javakt.common;

import java.util.Properties;

import com.tbd.training.javakt.common.logging.AppLogger;
/**
 *
 */
public final class StringUtil {
    private static AppLogger logger = AppLogger.getLogger(StringUtil.class);

    private static char replaceChar = '-';
    private static String forbiddenCharsPattern = "[',>,<,~,#]";
    
    private static Properties props;
    
    protected StringUtil() { }

    private static Properties getApplicationProperties() {
        //loading a property twice+ is not a big deal. 
        if (props == null) {
            props = PropertiesLoader.load("app.properties");
        }
        return props;
    }

    public static String decodeURL(String url) {
        String displayName = "";
        if (url != null) {
            displayName = url.replaceAll("%20", " ");
            displayName = displayName.replaceAll("%26", "&");
            displayName = displayName.replaceAll("%3C", "<");
            displayName = displayName.replaceAll("%3E", ">");
        }
        return displayName;
    }

    public static String encodeURL(String url) {
        String displayName = "";
        if (url != null) {
            displayName = url.replaceAll(" ", "%20");
            displayName = displayName.replaceAll("&", "%26");
            displayName = displayName.replaceAll("<", "%3C");
            displayName = displayName.replaceAll(">", "%3E");
        }
        return displayName;
    }

    public static String getMessage(String key) {
        return getApplicationProperties().getProperty(key);
    }

    public static String formatFileName(String pFilename) {
        StringBuffer sb = new StringBuffer();
        if (pFilename == null) {
            return "";
        }

        for (int i = 0; i < pFilename.length(); i++) {
            char c = pFilename.charAt(i);
            if (!((c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9')
                    || c == '.'))
            {
                sb.append(replaceChar);
            } else {
                sb.append(c);
            }
        }
        logger.debug(sb.toString());
        return sb.toString();
    }

    public static String escapeForbiddenChars(String pFilename) {
        return pFilename.replaceAll(forbiddenCharsPattern, "_");
    }

    public static String formatUrlPath(String path) {
        String reval = path.replace(" ", "").toLowerCase().replaceAll("[^0-9,a-z,_]", "_");
        logger.debug(reval);
        return reval;
    }

    public static boolean nullOrEmpty(String str) {
        return str == null || "".equals(str.trim());
    }
}
