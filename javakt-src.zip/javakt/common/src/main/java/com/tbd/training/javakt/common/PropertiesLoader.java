package com.tbd.training.javakt.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PropertiesLoader {
    private PropertiesLoader() {
        
    }

    public static Properties load(String fileName) {
        Properties props = new Properties();
        try (InputStream im = findFile(fileName)) {
            props.load(im);
        } catch (IOException ignore) {
            
        } 
        //replace ${} in the value with prop defined except itself
        Properties finalProps = props;
        for (Object key: props.keySet()) {
        	finalProps = parseTokens(props, (String)key, props.getProperty((String)key));
        }
        return finalProps;
    }
        
    private static Properties parseTokens(Properties props, String key, String valueWithTokens) {
    	if (props == null) {
    		props = new Properties();
    		return props;
    	}
    	String regex = "(\\$\\{(\\w+)\\})";   
    	Pattern pattern = Pattern.compile(regex);  
        Matcher matcher = pattern.matcher(valueWithTokens);
        String finalStr = valueWithTokens;
        while (matcher.find()) {
        	String token = matcher.group(1); //${key1}
        	String keyInToken = matcher.group(2); //key1
        	if (!key.equals(keyInToken)) {
        		finalStr = finalStr.replace(token, (String)props.get(keyInToken));
        	}
        }
        props.setProperty(key, finalStr);
        return props;
    }

    private static InputStream findFile(String fileName) throws FileNotFoundException {
        InputStream im = findInWorkingDirectory(fileName);
        if (im == null)
            im = findInClasspath(fileName);
        if (im == null)
            im = findInSourceDirectory(fileName);
        if (im == null)
            throw new FileNotFoundException(String.format("File %s not found", fileName));
        return im;
    }

    private static InputStream findInSourceDirectory(String fileName) throws FileNotFoundException {
        return new FileInputStream("src/main/resources/" + fileName);
    }

    private static InputStream findInClasspath(String fileName) {
        return Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
    }

    private static InputStream findInWorkingDirectory(String fileName) {
        try {
            return new FileInputStream(System.getProperty("props.dir") + fileName);
        } catch (FileNotFoundException e) {
            return null;
        }
    }
}
