package com.tbd.training.javakt.common.logging;

public interface LogOnce {

    Boolean isAlreadyLogged();

    void setAlreadyLogged(Boolean alreadyLogged);
}
