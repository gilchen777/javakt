package com.tbd.training.javakt.clientapp;

import java.io.File;
import java.util.List;

import com.tbd.training.javakt.common.WordCounter;

public class WordCountApp {
	public static void main(String[] args) {
		if (args.length >=2 && args[0].equals("--input")) {
			String filePath = args[1];
			File f = new File(filePath);
			if (f.exists()) {
				WordCounter target = new WordCounter();
				List<String> reval = target.findTopXWords(filePath, "UTF-8", 10);
				if (!reval.isEmpty()) {
					System.out.println(reval);
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
}
