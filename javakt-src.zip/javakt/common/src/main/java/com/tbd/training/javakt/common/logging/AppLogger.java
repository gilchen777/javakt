package com.tbd.training.javakt.common.logging;

import org.apache.log4j.Logger;

public final class AppLogger {
    private Logger logger;

    AppLogger(String category) {
        logger = Logger.getLogger(category);
    }

    public static AppLogger getLogger(Class<?> type) {
        return new AppLogger(type.getName());
    }

    public static AppLogger getLogger(String category) {
        return new AppLogger(category);
    }

    public void debug(Object object, Object... params) {
        if (isDebugEnabled()) {
            logger.debug(format(object, params));
        }
    }

    public void debug(Object object, Throwable t, Object... params) {
        if (logger.isDebugEnabled()) {
            if (t instanceof LogOnce) {
                LogOnce le = (LogOnce)t;
                if (le.isAlreadyLogged()) {
                    logger.debug(format(object, params));
                } else {
                    logger.debug(format(object, params), t);
                    le.setAlreadyLogged(Boolean.TRUE);
                }
            } else {
                logger.debug(format(object, params), t);
            }

        }
    }

    public void error(Object object, Object... params) {
        logger.error(format(object, params));
    }

    public void error(Object object, Throwable t, Object... params) {
        if (t instanceof LogOnce) {
            LogOnce le = (LogOnce)t;
            if (le.isAlreadyLogged()) {
                logger.error(format(object, params));
            } else {
                logger.error(format(object, params), t);
                le.setAlreadyLogged(Boolean.TRUE);
            }
        } else {
            logger.error(format(object, params), t);
        }
    }

    public void fatal(Object object, Object... params) {
        logger.fatal(format(object, params));
    }

    public void fatal(Object object, Throwable t, Object... params) {
        if (t instanceof LogOnce) {
            LogOnce le = (LogOnce)t;
            if (le.isAlreadyLogged()) {
                logger.fatal(format(object, params));
            } else {
                logger.fatal(format(object, params), t);
                le.setAlreadyLogged(Boolean.TRUE);
            }
        } else {
            logger.fatal(format(object, params), t);
        }
    }

    public void info(Object object, Object... params) {
        if (logger.isInfoEnabled()) {
            logger.info(format(object, params));
        }
    }

    public void info(Object object, Throwable t, Object... params) {
        if (logger.isInfoEnabled()) {
            if (t instanceof LogOnce) {
                LogOnce le = (LogOnce)t;
                if (le.isAlreadyLogged()) {
                    logger.info(format(object, params));
                } else {
                    logger.info(format(object, params), t);
                    le.setAlreadyLogged(Boolean.TRUE);
                }
            } else {
                logger.info(format(object, params), t);
            }
        }
    }

    public boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }

    public boolean isInfoEnabled() {
        return logger.isInfoEnabled();
    }

    public boolean isTraceEnabled() {
        return logger.isTraceEnabled();
    }

    public void trace(Object object, Object... params) {
        if (isTraceEnabled()) {
            logger.trace(format(object, params));
        }
    }

    public void trace(Object object, Throwable t, Object... params) {
        if (isTraceEnabled()) {
            if (t instanceof LogOnce) {
                LogOnce le = (LogOnce)t;
                if (le.isAlreadyLogged()) {
                    logger.trace(format(object, params));
                } else {
                    logger.trace(format(object, params), t);
                }
            } else {
                logger.trace(format(object, params), t);
            }
        }
    }

    public void warn(Object object, Object... params) {
        logger.warn(format(object, params));
    }

    public void warn(Object object, Throwable t, Object... params) {
        if (t instanceof LogOnce) {
            LogOnce le = (LogOnce)t;
            if (le.isAlreadyLogged()) {
                logger.warn(format(object, params));
            } else {
                logger.warn(format(object, params), t);
            }
        } else {
            logger.warn(format(object, params), t);
        }
    }


    private Object format(Object object, Object... params) {
        if (object instanceof String && params.length > 0) {
            return String.format((String)object, params);
        }
        return object;
    }

}
